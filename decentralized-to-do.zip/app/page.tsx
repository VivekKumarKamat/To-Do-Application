"use client"

import Home from "../frontend/pages/index"

export default function SyntheticV0PageForDeployment() {
  return <Home />
}