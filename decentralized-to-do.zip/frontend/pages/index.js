import { useState, useEffect } from 'react'
import TaskList from '../components/TaskList'
import TaskForm from '../components/TaskForm'
import Analytics from '../components/Analytics'
import styles from '../styles/Home.module.css'

export default function Home() {
  const [tasks, setTasks] = useState([])

  useEffect(() => {
    // Fetch tasks from the backend
    fetchTasks()
  }, [])

  const fetchTasks = async () => {
    const response = await fetch('/api/tasks')
    const data = await response.json()
    setTasks(data)
  }

  const addTask = async (task) => {
    const response = await fetch('/api/tasks', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(task),
    })
    const newTask = await response.json()
    setTasks([...tasks, newTask])
  }

  const updateTask = async (id, updates) => {
    const response = await fetch(`/api/tasks/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updates),
    })
    const updatedTask = await response.json()
    setTasks(tasks.map(task => task.id === id ? updatedTask : task))
  }

  const deleteTask = async (id) => {
    await fetch(`/api/tasks/${id}`, { method: 'DELETE' })
    setTasks(tasks.filter(task => task.id !== id))
  }

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Decentralized To-Do App</h1>
      <TaskForm addTask={addTask} />
      <TaskList tasks={tasks} updateTask={updateTask} deleteTask={deleteTask} />
      <Analytics tasks={tasks} />
    </div>
  )
}

