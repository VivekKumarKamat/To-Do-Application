import styles from '../styles/Analytics.module.css'

export default function Analytics({ tasks }) {
  const completedTasks = tasks.filter(task => task.completed).length
  const totalTasks = tasks.length
  const completionPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0

  return (
    <div className={styles.analytics}>
      <h2>Task Completion Analytics</h2>
      <p>Completed Tasks: {completedTasks} / {totalTasks}</p>
      <p>Completion Percentage: {completionPercentage.toFixed(2)}%</p>
    </div>
  )
}

