import { useState } from 'react'
import styles from '../styles/TaskForm.module.css'

export default function TaskForm({ addTask }) {
  const [title, setTitle] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!title.trim()) return
    addTask({ title, completed: false })
    setTitle('')
  }

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Add a new task"
        className={styles.input}
      />
      <button type="submit" className={styles.button}>Add Task</button>
    </form>
  )
}

