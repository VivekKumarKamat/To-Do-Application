import styles from '../styles/TaskList.module.css'

export default function TaskList({ tasks, updateTask, deleteTask }) {
  return (
    <ul className={styles.taskList}>
      {tasks.map(task => (
        <li key={task.id} className={styles.taskItem}>
          <input
            type="checkbox"
            checked={task.completed}
            onChange={() => updateTask(task.id, { completed: !task.completed })}
          />
          <span className={task.completed ? styles.completed : ''}>{task.title}</span>
          <button onClick={() => deleteTask(task.id)}>Delete</button>
        </li>
      ))}
    </ul>
  )
}

