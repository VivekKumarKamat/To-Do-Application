const { OpenAI } = require("langchain/llms/openai");
const { PromptTemplate } = require("langchain/prompts");
const { LLMChain } = require("langchain/chains");

const model = new OpenAI({ temperature: 0.9 });

const template = `
You are a task prioritization AI. Given the following tasks, prioritize them based on importance and urgency.
Each task has a title and a completed status.

Tasks:
{tasks}

Provide a JSON array of the tasks in priority order, with the highest priority first. Include a "priority" field for each task.
`;

const prompt = new PromptTemplate({
  template: template,
  inputVariables: ["tasks"],
});

const chain = new LLMChain({ llm: model, prompt: prompt });

exports.prioritizeTasks = async (tasks) => {
  const taskString = tasks.map(task => `Title: ${task.title}, Completed: ${task.completed}`).join('\n');
  const result = await chain.call({ tasks: taskString });
  return JSON.parse(result.text);
};

